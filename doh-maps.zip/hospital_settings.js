
var spreadsheets = [
	
	{
		'key' : '0Aj-7MceMcnWtdGRMcEN3YWwzc01RUkRNaDVPRjJaSHc/od6',
		'description' : 'Hospital',
		'keyword' : 'hospital',
		'marker' : 'static/hospital_.png'
	}
];

var services = {
	'xrayservices' : {'description': 'X-ray Service'},
	'bloodbank' : {'description': 'Blood Bank'},
	'bloodcollection' : {'description': 'Blood Collection Unit'},
	'apheresis' : {'description': 'Apheresis Facility'},
	'hivtesting' : {'description': 'HIV Testing Lab'},
	'drinkingwater' : {'description': 'Drinking Water Analysis Lab'},
	'drugscreening' : {'description': 'Drug Screening Lab'},
	'pharmacy' : {'description': 'Pharmacy' }
}