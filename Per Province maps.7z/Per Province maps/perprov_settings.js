var provsheets = {
'NCR': { 
	'poisheets': [
	'0Aq7eQ20tUwmTdFJwUWpDako1WS1LRU10ZDE4YlZIbmc/od6', // government hospitals
	'0Ahdqio3d31tKdDh0VFkzUEk5YmF2emxPbEVxZVJlcVE/od6', // Clinical Labs
	'0Aq7eQ20tUwmTdFJwUWpDako1WS1LRU10ZDE4YlZIbmc/od7', // private hospitals
	'0Aq7eQ20tUwmTdFJwUWpDako1WS1LRU10ZDE4YlZIbmc/od4', // RHU
	'0Aq7eQ20tUwmTdFJwUWpDako1WS1LRU10ZDE4YlZIbmc/od8' // BHS
	'0Aq7eQ20tUwmTdFJwUWpDako1WS1LRU10ZDE4YlZIbmc/od5' // LIC & HC
	'0Aq7eQ20tUwmTdFJwUWpDako1WS1LRU10ZDE4YlZIbmc/oda' // LIC
	'0Ahdqio3d31tKdDh0VFkzUEk5YmF2emxPbEVxZVJlcVE/od7' // city
	],
	'shapesheets': ['0Aq7eQ20tUwmTdDRsenVrYUZyMlBUbnhvbXlQdFoxNWc/od8'],
	'zoom':10,
	'center': [14.61409, 121.03773]
}

};