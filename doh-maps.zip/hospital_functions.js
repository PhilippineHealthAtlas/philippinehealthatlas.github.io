var map;
var circle = null;
var geocoder;
var categories = [];
var myLoc = '';
var localsearch = null;
var infoboxOptions = {
	content: '',
	disableAutoPan: true,
	maxWidth: 0,
	pixelOffset: new google.maps.Size(-10, -10),
	zIndex: null,
	boxClass: 'infobox',
	boxStyle: { },
	//closeBoxMargin: "2px 2px 2px 2px",
	closeBoxMargin: "0px 0px 0px 0px",
	closeBoxURL: '',// "http://www.google.com/intl/en_us/mapfiles/close.gif",
	infoBoxClearance: new google.maps.Size(1, 1),
	isHidden: false,
	//pane: "floatPane",
	pane: "overlayImage",
	//pane: "mapPane",
	enableEventPropagation: false
};
var SPREADSHEET_URL_BASE = 'https://spreadsheets.google.com/feeds/list/',
	SPREADSHEET_URL_END = '/public/values',
	categ_ss = {};
var infotipOptions = {
	content: '',
	disableAutoPan: true,
	maxWidth: 0,
	pixelOffset: new google.maps.Size(10, 10),
	zIndex: null,
	boxClass: 'infotip',
	boxStyle: { },
	closeBoxMargin: "0px 0px 0px 0px",
	closeBoxURL: "http://www.google.com/intl/en_us/mapfiles/close.gif",
	infoBoxClearance: new google.maps.Size(1, 1),
	isHidden: false,
	pane: "floatPane",
	enableEventPropagation: false
};
var infotipbox = null;
var layers ;
//https://docs.google.com/spreadsheet/tq?tq=SELECT+B,G,H,I,O+WHERE+H%3E0&key=0Ai5xV-_s2GaFdF9Zc1NNeU1qNllqYjFWZWZKQWJKVlE&hl=en_US&gid=0&tqx=responseHandler:wayne

var infoWindow = new google.maps.InfoWindow({ pixelOffset: google.maps.Size(0,0), maxWidth: 200});

var errorIcon = new google.maps.MarkerImage(
		'static/home.png',
		new google.maps.Size(24, 24),
		new google.maps.Point(0, 0),
		new google.maps.Point(12, 12));
var hospitalIcon = new google.maps.MarkerImage(
		'static/hospital_.png',
		new google.maps.Size(10, 10),
		new google.maps.Point(0, 0),
		new google.maps.Point(5, 5));
var fadedIcon = new google.maps.MarkerImage(
		'static/hospital_faded.png',
		new google.maps.Size(10, 10),
		new google.maps.Point(0, 0),
		new google.maps.Point(5, 5));
		
function onLoad() {
	layers = {
	};
	var initOptions = {
		zoom: 8,
		center : new google.maps.LatLng(14.6137, 121.0376),
		disableDefaultUI: false,
		mapTypeId: google.maps.MapTypeId.TERRAIN
	};
	map = new google.maps.Map(document.getElementById("map"), initOptions); 
		
	for(var layer in layers) {
		addTR(layer, layers[layer].name);
	}
	
	for (var i = 0; i < spreadsheets.length; i++) {
		m = spreadsheets[i];
		categ_ss[m.key] = m.keyword;
		categories[m.keyword] = m;
		categories[m.keyword].infoboxes = [];
		var newInput = $('<input>')
			.attr({'type':'checkbox', 'id': 'cb_' + m.keyword, 'name': m.keyword, 'checked':true})
			.click(toggleCheckboxes);
		var newLabel = $('<label>')
			.attr({'for': 'cb_' + m.keyword})
			.html(' '+m.description);
		var newImage = $('<img>')
			.attr({'src': m.marker})
			.html(m.description);
		var newDiv = $('<div>')
			.append(newInput)
			.append(newImage)
			.append(newLabel);
		$('#addressbar .padding').append(newDiv);
		fetchGoogleSpreadsheet(m.key, 'displayFeaturesNew');
		//fetchSpreadsheet(m.keyword);
	}
	
	for (var i in services) {
		m = services[i];
		m.keyword = i;
		var newInput = $('<input>')
			.attr({'type':'checkbox', 'id': 'cb_' + m.keyword , 'name': m.keyword})
			.click(toggleCheckboxes_services);
		var newLabel = $('<label>')
			.attr({'for': m.keyword})
			.html(' '+m.description);
		var newDiv = $('<div>')
			.append(newInput)
			.append(newLabel);
		$('#addressbar .padding').append(newDiv);
	}
	
	var newInput = $('<input>')
			.attr({'type':'button', 'id': 'cb_' + m.keyword , 'name': 'service', 'value': 'Clear'})
			.click(clearHide);
		
		var newDiv = $('<div>')
			.append(newInput);
		$('#addressbar .padding').append(newDiv);
} 

function clearHide() {
	var items = categories[categ].items;
	for (var j = 0; j < items.length; j++) {
		items[j].marker.setIcon(hospitalIcon);
		items[j].market.setMap(map);
	}
}

hideInfotipWindow = function() {
	infoWindow.close();
}

function toggleCheckboxes () {
	categ = $(this).attr('name');
	$('#div_'+categ).toggleClass('hidden');
	var infoboxes = categories[categ].infoboxes
	for (var j = 0; j < infoboxes.length; j++) {
		if (infoboxes[j].getMap() == null) {
			infoboxes[j].setMap(map);
		} else {
			infoboxes[j].setMap(null);
		}
	}
	
	var items = categories[categ].items;
	for (var j = 0; j < items.length; j++) {
		if (items[j].marker.getMap() == null) {
			items[j].marker.setMap(map);
		} else {
			items[j].marker.setMap(null);
		}
	}	
}

function toggleCheckboxes_services() {
	service = $(this).attr('name');
	var items = categories['hospital'].items;
	nn = 0;
	for (var k in services) {
		//alert($('#cb_' + k).attr('checked'));
		if ($('#cb_' + k).attr('checked')) {
			nn++;
		}
	}
	for (var j in items) {
		var m = items[j];
		var n = 0;
		var datum = $(m.marker).data('datum');
		for (var k in services) {
			if (datum[k] == '1' && $('#cb_' + k).attr('checked')) {
				//alert(datum[k]);
				n++;
			}
		}
		if (n == nn) {
			items[j].marker.setMap(map);
		} else {
			items[j].marker.setMap(null);
		}
		/*
		if (datum != null) {
			if (datum[service] == '1') {
				//items[j].marker.setIcon(hospitalIcon);
				items[j].marker.setMap(map);
			} 
			else {
				//items[j].marker.setIcon(fadedIcon);
				items[j].marker.setMap(null);
			} 
		} else {
			items[j].marker.setIcon(errorIcon);
		}
		*/
	}
}


function addTR(id) {
	var input = $("<input>")
		.attr({
			'type': "checkbox",
			'id': id,
			'checked': (layers[id].defaultLayer)
		})
		.click (function () { toggleGeoXML(this.id, this.checked) });
	var inputTD = $("<td>")
	var nameTD = $("<td>");
	var layerTR = $("<tr>");
	var nameA = $("<b>")
		.html(layers[id].name);
	var source = $("<b>")
		.html(layers[id].name);
	var legendText = $('<div>')
		.html('<div><i>Source: '+layers[id].source+'</i></div>'+layers[id].legend)
		.attr('id','legend_'+id);
	if (! layers[id].defaultLayer) {
		legendText.addClass('hidden');
	}
	inputTD
		.append(input);
	nameTD
		.append(nameA)
		.append(legendText);
	layerTR
		.append(inputTD)
		.append(nameTD);
	$("#legendbarTBODY").append(layerTR);
	$(".legend_item")
		.mouseenter( function() {
			$(this).addClass('hover');
		})
		.mouseleave( function() {
			$(this).removeClass('hover');
		});
	layers[id].geoXmls = []
	for (var j = 0; j < layers[id].urls.length; j++) {
		var geoXml = new google.maps.KmlLayer(layers[id].urls[j], {
			map: (layers[id].defaultLayer ? map : null),
			preserveViewport: true,
			suppressInfoWindows: layers[id].suppressInfoWindows
		});
		layers[id].geoXmls.push(geoXml);
	}
	//toggleGeoXML(layer, true);
}

function toggleGeoXML(id, checked) {
	for (var currLayer in layers) {
		geoXmls = layers[currLayer].geoXmls;
		for (var i = 0; i < geoXmls.length; i++) {
			if (checked && currLayer == id) {
				$('#legend_'+id).removeClass('hidden');
				geoXmls[i].setMap(map);
			} else {
				$('#'+currLayer).attr('checked',false);
				$('#legend_'+currLayer).addClass('hidden');
				geoXmls[i].setMap(null);
			}
		}
	}
}

function onLocalSearch() {
	if (localsearch.results.length > 0) {
		var first = localsearch.results[0];
		var position = new google.maps.LatLng(parseFloat(first.lat), parseFloat(first.lng));
		myLoc = first.title;
		map.setCenter(position);
		var marker = new google.maps.Marker({
			map: map,
			position: position });
		marker.address = first.title;
		infoWindow.setContent(
			"Search result: "
			+ '<h1>' + marker.address + '</h1>'
		);
		infoWindow.open(map,marker);
		google.maps.event.addListener(marker, 'click', function() {
			infoWindow.setContent('<h1>'+"Search result: "+'</h1>' + this.address);
			infoWindow.open(map,this);
		});
		map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
		showNearby();
	} else {
		
		$('#nearby .padding').empty().addClass('hidden');
		alert("Sorry, Google was unable to geocode that address");
	}
}

function roundOff(num, dec) {
	return Math.round(num*Math.pow(10,-dec))/Math.pow(10,-dec);
}

function showNearby() {
	var currLoc = map.getCenter();
	//newBounds = new map.google.LatLngBounds();
	newBounds = new google.maps.LatLngBounds(map.getCenter(),map.getCenter());
	var radiusLimit = 5;
	$('#nearby').removeClass('hidden');
	var nearby = $('#nearby');
	nearby.empty();
	var header = $('<div>')
		.html(
			'<a id="printlink" href="javascript:window.print()"><div><img src="icon_print.gif"/> <b>Print this List</b></div></a>'
			+'<br/>'
			+'<div>Your location is '+myLoc+'.</div>'
			+'<br/>'
			+'<h1>Nearest your location:</h1>'
			)
		.addClass('padding')
		;
	nearby
		.append(header);
	
	for (var categ in categories) {
		if ($('#cb_'+categ).attr('checked')) {
			distances = [];
			var category = categories[categ];
			var infoboxes = category.infoboxes;
			while (infoboxes.length>0) {
				infoboxes[infoboxes.length-1].setMap(null);
				infoboxes.pop();
			}
			ecs = categories[categ].items;
			for (var i = 0; i < ecs.length; i++) {
				var distance = getDistance(currLoc, ecs[i].position);
				if ( distance < radiusLimit) {
					distances.push({n: i, distance: distance });
				}
			}
			distances.sort(sortLocations);
			
			parentDiv = $('<div>')
				.attr( {'id':'div_'+categ})
				//.addClass('container')
				;
			categDiv = $('<div>')
				.addClass('padding')
				;
			parentDiv.append(categDiv);
			categDiv.append($('<h2>').html(category.description));
			newList = $('<ul>');
			categDiv.append(newList);
			nearby.append(parentDiv);
			if (distances.length == 0) {
				newMarker = $('<li>')
					.html('None found within ' + radiusLimit + ' kilometers');
				newList.append(newMarker);
			}
			for (var i = 0; i < 5 && i < distances.length; i++) {
				x = distances[i].n
				var thisLoc = ecs[x];
				newBounds = newBounds.extend(thisLoc.position);
				
				var ib = new InfoBox(infoboxOptions);	
				ib.open(map, thisLoc.marker);
				if (thisLoc.name) {
					//ib.setContent('<div>'+thisLoc.name+'</div>');
				}
				category.infoboxes.push(ib);
				
				newMarker = $('<li>')
					.html('<b>' + thisLoc.name + '</b> (' 
						+ roundOff(distances[i].distance,-2) + ' km)'
						+(ecs[x]['Contact Numbers'] ? '<br/>' + '<img src="phone.png" alt="Contact Numbers:"/> ' + ecs[x]['Contact Numbers'] : '')
						)
					.data('datum', ecs[x])
					.click(showMarkerInfoWindow)
					.mouseover(showMarkerInfoWindow)
					;
				newList.append(newMarker);
			}
		}
	}
	map.fitBounds(newBounds);
	/*
	new google.maps.Rectangle({
			fillColor:'#ff3f3f', 
			strokeOpacity: 0, 
			map:map,
			bounds:newBounds 
		});
	*/
}

showMarkerInfoWindow = function () {
	var datum = $(this).data('datum');
	var text = 
//		categories[datum.category].description +':'
		''
		+'<h1>'+datum.name+'</h1>'
		+(datum['address'] ? '<br class="address"/>' + datum['address'] + ', ' : '')
		+(datum['city'] ? ', ' + datum['city'] : '')
		+(datum['province'] ? ', ' + datum['province'] : '')
		+(datum['region'] ? '<br/>Region ' + datum['region'] : '')
		+(datum['ownership'] ? '<br/>Ownership: ' + datum['ownership'] : '')
		+(datum['bedcapacity'] ? '<br/>Authorized Bed Capacity: ' + datum['bedcapacity'] : '')
		+(datum['servicecapability'] ? '<br/>Service Capability: Level ' + datum['servicecapability'] : '')
		+(datum['xrayservice'] ? '<br/>Xray Services: ' + datum['xrayservice'] : '')
		+'<br/></br><b>Ancillary Services</b>:'
		;
	var j = 0;
	for (var i in services) {
		if (datum[i] == '1') {
			text += '<br/>' + services[i].description;
			j++;
		}
	}
	if (j == 0) {
		text += '<br/>none';
	}
	infoWindow.setContent(text);
	infoWindow.open(map,(datum.marker||datum));
	
}

function sortLocations(a,b) {
	return a.distance - b.distance;
}

function roundOff(num, dec) {
	return Math.round(num*Math.pow(10,-dec))/Math.pow(10,-dec);
}




function cleanJson(entry) {
	for (var i in entry) {
		//alert(i);
		if (i.match(/^gsx\$/)) {
			entry[i.replace('gsx$','')] = entry[i].$t;
		}
	}
	return entry;
}

function displayFeaturesNew(result) {
	var items = result.feed.entry,
	ss_id = result.feed.id.$t.replace(SPREADSHEET_URL_BASE,'').replace(SPREADSHEET_URL_END,'');
	categ = categ_ss[ss_id];
	//alert(ss_id);
	//alert(0);
	var icon = new google.maps.MarkerImage(
		categories[categ].marker,
		new google.maps.Size(10, 10),
		new google.maps.Point(0, 0),
		new google.maps.Point(5, 5));
	//alert(items.length);
	//alert(items.length);
	for (var i = 0; i < items.length; i++) {
		items[i] = cleanJson(items[i]);
		if (items[i].xrayservices) {
			items[i].xrayservices = (items[i].xrayservice.length > 0 ? '1' : '0');
		}
		//alert(items[i].latitude);
		//if (items[i].latitude);
		items[i].category = categ;
		items[i].position = new google.maps.LatLng(
			parseFloat(items[i].latitude), 
			parseFloat(items[i].longitude));
		var marker = new google.maps.Marker({
			map: map,
			position: items[i].position,
			icon: icon
		});
		google.maps.event.addListener(marker, 'click', showMarkerInfoWindow);
		//google.maps.event.addListener(marker, 'mouseover', showMarkerInfoWindow);
		items[i].marker = marker;
		$(marker).data('datum', items[i]);
	}
	categories[categ].items = items;
}



function fetchGoogleSpreadsheet(ws_key, callback) {
	t = (new Date()).getTime();
	
	script_url = SPREADSHEET_URL_BASE
				+ ws_key
				+ SPREADSHEET_URL_END
				+ '?alt=json-in-script'
				+ '&callback='+callback
				+ '&t='+(roundOff((new Date()).getTime(),-2));
				//alert(script_url);
	newScript = $('<script>')
		.attr({
			'src': script_url,
			'type': 'text/javascript'
			
		});
	$(document.body).append(newScript);
	
}

function fetchSpreadsheet(category) {
	t = (new Date()).getTime();
	newScript = $('<script>')
		.attr('src', category + 's.js');
	$(document.body).append(newScript);
}

function deg2rad(deg) { return deg*Math.PI/180; }
function degsin(deg) { return Math.sin(deg2rad(deg)); }
function degcos(deg) { return Math.cos(deg2rad(deg)); }
